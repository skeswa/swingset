"""One bounded, resumable archive dispatch through the ordinary fetch and parse pipeline."""

from __future__ import annotations

import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Protocol

from swingset.admission.generations import deserialize_result
from swingset.clock import Clock
from swingset.config import Config
from swingset.fetch.client import FetchResult
from swingset.fetch.wayback import Capture, schedule_capture
from swingset.history.acquisition import phase_two_gate
from swingset.history.captures import next_capture
from swingset.history.platform import PlannedPage, PlatformPlan, retained_plan
from swingset.schedule.watches import due_watches, refresh_policy
from swingset.sources import get_page_kind
from swingset.sources.base import PageKind, WatchSpec
from swingset.state.control_scopes import for_watch
from swingset.state.controls import matching_pauses
from swingset.state.db import Database
from swingset.state.findings import Finding, replace_findings
from swingset.state.work import runnable_exists

if TYPE_CHECKING:
    from swingset.history.archive_timing import OfferTiming


class Fetcher(Protocol):
    def fetch(
        self,
        watch_id: str,
        page_kind: PageKind,
        run_id: str,
        *,
        deadline: datetime | None = None,
    ) -> FetchResult: ...


@dataclass(frozen=True)
class Dispatch:
    reason: str
    watch_id: str | None = None
    capture: Capture | None = None
    result: FetchResult | None = None


def _busy(database: Database, config: Config, clock: Clock, deadline: datetime) -> str | None:
    conn = database.connection
    if (deadline - clock.now()).total_seconds() <= 120:
        return "wall_clock_reserve"
    from urllib.parse import urlsplit

    from swingset.state.control_scopes import unit_allowed

    if runnable_exists(
        conn, now=clock.now(), allowed=lambda unit: unit_allowed(conn, unit, now=clock.now())
    ):
        return "pipeline_work_pending"
    for watch_id in due_watches(conn, config, clock.now()):
        watch = conn.execute(
            "SELECT state,priority,source,url,archive_url FROM watches WHERE watch_id=?",
            (watch_id,),
        ).fetchone()
        if matching_pauses(
            conn,
            for_watch(
                conn,
                source=watch["source"],
                watch_id=watch_id,
                host=urlsplit(watch["archive_url"] or watch["url"]).hostname,
            ),
            now=clock.now(),
        ):
            continue
        if watch[0] != "backfill" or watch[1] != 6:
            return "other_watch_due"
    return None


def _parent_ready(
    database: Database, item: PlannedPage, plan: PlatformPlan, *, now: datetime
) -> bool:
    if item.page.kind != "round":
        return True
    parents = [
        p
        for p in plan.pages
        if p.page.source == item.page.source
        and p.event.event_id == item.event.event_id
        and p.page.kind != "round"
        and (p.page.url == item.page.parent_url or item.page.parent_url is None)
    ]
    for parent in parents:
        candidate, state = next_capture(database.connection, parent, now=now)
        if candidate or state == "waiting":
            return False
        # A partial parent may still supply independently admitted round links after
        # its three capture alternatives are exhausted. Do not invent those links.
        retained = database.connection.execute(
            "SELECT g.result_json FROM source_units u JOIN source_generations g ON g.generation_id=u.accepted_generation_id JOIN watches w ON w.watch_id=u.watch_id WHERE w.source=? AND w.url=? AND g.state='accepted'",
            (parent.page.source, parent.page.url),
        ).fetchone()
        if retained:
            declarations = deserialize_result(str(retained[0])).watches
            if any(
                child.url == item.page.url
                and child.source_ref == item.page.source_ref
                and child.source == item.page.source
                for child in declarations
            ):
                return True
    return False


def _candidate(
    database: Database,
    config: Config,
    clock: Clock,
    item: PlannedPage,
    plan: PlatformPlan,
    *,
    year_allowed: Callable[[int], bool] | None = None,
) -> tuple[WatchSpec | None, Capture | None, str]:
    conn, page = database.connection, item.page
    if not config.enabled(page.source):
        return None, None, "source_disabled"
    spec = WatchSpec(
        "", page.source, page.kind, "GET", page.url, page.page_kind, source_ref=page.source_ref
    )
    if matching_pauses(
        conn,
        for_watch(
            conn,
            source=page.source,
            watch_id=spec.watch_id,
            page_kind=page.page_kind,
            watch_kind=page.kind,
            host="web.archive.org",
        ),
        now=clock.now(),
    ):
        return None, None, "operator_pause"
    if item.event.last_day >= clock.now().date():
        return None, None, "event_not_historical"
    if reason := phase_two_gate(
        conn,
        source=page.source,
        source_ref=page.source_ref,
        page_kind=page.page_kind,
        year_allowed=year_allowed,
    ):
        return None, None, reason
    actual = conn.execute(
        "SELECT e.event_id,e.year,e.event_month,e.end_date FROM source_event_map m JOIN events e USING(event_id) WHERE m.source=? AND m.source_ref=?",
        (page.source, page.source_ref),
    ).fetchone()
    if actual is None or tuple(actual) != (
        item.event.event_id,
        item.event.year,
        item.event.event_month,
        item.event.end_date.isoformat() if item.event.end_date else None,
    ):
        return None, None, "plan_mapping_changed"
    capture, state = next_capture(conn, item, now=clock.now())
    if capture is None:
        return None, None, state
    if not _parent_ready(database, item, plan, now=clock.now()):
        return None, None, "parent_document_pending"
    spec = replace(spec, archive_url=capture.archive_url)
    existing = conn.execute(
        "SELECT state,next_check_at,paused_until,archive_url FROM watches WHERE watch_id=?",
        (spec.watch_id,),
    ).fetchone()
    advancing = bool(
        existing
        and existing[0] == "backfill"
        and existing[3]
        and existing[3] != capture.archive_url
    )
    if existing and (
        existing[0] in {"gone", "paused"}
        or (existing[2] and datetime.fromisoformat(existing[2]) > clock.now())
        or (
            existing[0] != "sealed"
            and not advancing
            and existing[1]
            and datetime.fromisoformat(existing[1]) > clock.now()
        )
    ):
        return None, None, "watch_cooldown"
    return spec, capture, "eligible"


def _options(
    database: Database,
    config: Config,
    clock: Clock,
    plan: PlatformPlan,
    *,
    deadline: datetime | None,
) -> tuple[list[tuple[PlannedPage, tuple[WatchSpec | None, Capture | None, str]]], bool]:
    """Evaluate plan pages in order until ``deadline``; also say whether it cut the pass."""
    from swingset.log import log
    from swingset.project.history import projection_answer_cached

    year_allowed = _year_gate(database.connection)
    options: list[tuple[PlannedPage, tuple[WatchSpec | None, Capture | None, str]]] = []
    with projection_answer_cached():
        for item in plan.pages:
            if deadline is not None and clock.now() >= deadline:
                log("history_offers_truncated", evaluated=len(options), pages=len(plan.pages))
                return options, True
            options.append(
                (item, _candidate(database, config, clock, item, plan, year_allowed=year_allowed))
            )
    return options, False


def offers(
    database: Database,
    config: Config,
    clock: Clock,
    *,
    plan: PlatformPlan | None = None,
    run_id: str | None = None,
    timing: OfferTiming | None = None,
    deadline: datetime | None = None,
) -> tuple[WatchSpec, ...]:
    """Expose the finite eligible plan to ordinary rotation without scheduling it.

    Plan order admits newer events first. All waiting candidates remain visible
    together, so that order cannot override an already enrolled event turn.
    Dispatch repeats the year, parent, capture, and source gates before mutation.
    Only archive captures are offered: a page whose captures are exhausted
    makes no origin request (D-0236). ``run_id`` only stamps ``timing``.

    The year gate is answered once per year for the whole pass: it walks every
    pending projection unit, and asking it per page made one pass over 6,247
    pages take 43 minutes (D-0181). A ``deadline`` stops the pass early; the
    pages not reached are offered on a later pass.
    """
    if timing is not None:
        timing.begin(connection=database.connection, config=config, clock=clock, run_id=run_id)
    plan = plan or retained_plan(database.connection, history_start=config.history_start)
    from swingset.project.history import projection_answer_cached

    result: dict[str, WatchSpec] = {}
    # One answer to the projection question for the whole pass (D-0195).
    with projection_answer_cached():
        options, _ = _options(database, config, clock, plan, deadline=deadline)
        for _, (spec, _, _) in options:
            if spec is not None:
                result.setdefault(spec.watch_id, spec)
    if timing is not None:
        timing.finish(result)
    return tuple(result.values())


@dataclass(frozen=True)
class PagePlan:
    """One planned page as the plan loop records it (D-0218).

    ``spec`` is what acquire offers when ``eligible``: the archive capture's
    spec. ``reason`` is ``eligible`` or the `_candidate` stop reason.
    """

    item: PlannedPage
    watch_id: str
    rank: int
    reason: str
    spec: WatchSpec | None = None

    @property
    def eligible(self) -> bool:
        return self.spec is not None


@dataclass(frozen=True)
class PlannedPages:
    pages: tuple[PagePlan, ...]
    #: The deadline cut the pass: pages after the last one were not evaluated.
    truncated: bool
    evaluated: int


def plan_pages(
    database: Database,
    config: Config,
    clock: Clock,
    *,
    deadline: datetime | None,
    plan: PlatformPlan | None = None,
) -> PlannedPages:
    """Evaluate the retained plan as `offers` does and keep every page's reason.

    One row per watch, in plan order: the first eligible page of a watch, as
    `offers` would offer it, else the watch's first page. ``rank`` is the
    page's position in the plan. Nothing is written.
    """
    from swingset.project.history import projection_answer_cached

    plan = plan or retained_plan(database.connection, history_start=config.history_start)
    with projection_answer_cached():
        options, truncated = _options(database, config, clock, plan, deadline=deadline)
        chosen: dict[str, PagePlan] = {}
        for rank, (item, (spec, _, reason)) in enumerate(options):
            watch_id = page_watch_id(item)
            page = PagePlan(item, watch_id, rank, "eligible" if spec is not None else reason, spec)
            previous = chosen.get(watch_id)
            if previous is None or (page.eligible and not previous.eligible):
                chosen[watch_id] = page
    return PlannedPages(
        tuple(sorted(chosen.values(), key=lambda page: page.rank)), truncated, len(options)
    )


def offer(
    database: Database,
    config: Config,
    clock: Clock,
    *,
    plan: PlatformPlan | None = None,
    run_id: str | None = None,
) -> WatchSpec | None:
    """Compatibility for callers requesting only the plan's first candidate."""
    return next(iter(offers(database, config, clock, plan=plan, run_id=run_id)), None)


def _year_gate(conn: sqlite3.Connection) -> Callable[[int], bool]:
    """Answer the phase-two year gate once per year and the projection question once.

    The projection question walks every pending derivation and costs seconds on
    a large database, so one pass over thousands of plan pages must not repeat
    it per page or per year (D-0181, D-0195).
    """
    from swingset.project.history import (
        facts_only,
        pending_inventory_projection,
        phase_two_allowed,
    )

    years: dict[int, bool] = {}
    pending: list[bool] = []

    def year_allowed(year: int) -> bool:
        if year not in years:
            if not pending:
                # The facts-only gate never asks the question (D-0218).
                pending.append(False if facts_only() else pending_inventory_projection(conn))
            years[year] = phase_two_allowed(conn, year, pending=pending[0])
        return years[year]

    return year_allowed


def page_watch_id(item: PlannedPage) -> str:
    """The watch a planned page dispatches to; plan rows and offers are keyed by it."""
    page = item.page
    return WatchSpec(
        "", page.source, page.kind, "GET", page.url, page.page_kind, source_ref=page.source_ref
    ).watch_id


def dispatch_one(
    database: Database,
    config: Config,
    clock: Clock,
    run_id: str,
    *,
    deadline: datetime,
    fetcher: Fetcher,
    plan: PlatformPlan | None = None,
    allocated: bool = False,
    target_watch_id: str | None = None,
) -> Dispatch:
    """Create/advance at most one watch atomically, then perform at most one gated fetch.

    The caller owns the database process lock. An allocated turn may coexist with
    unrelated backlog; direct calls retain the downstream reserve. Snapshots and
    selected generations are the durable resume ledger in both cases.
    """
    if clock.now() >= deadline:
        return Dispatch("wall_clock_reserve")
    if not allocated and (reason := _busy(database, config, clock, deadline)):
        return Dispatch(reason)
    plan = plan or retained_plan(database.connection, history_start=config.history_start)
    conn = database.connection
    gaps = list(plan.findings)
    chosen: tuple[PlannedPage, Capture, WatchSpec] | None = None
    blocked = "no_eligible_capture"
    from swingset.schedule.event_timing_observer import checkpoint, resume

    # An allocated turn names its watch, so only that page needs evaluating.
    # Everything else is one bounded write, and evaluating thousands of pages
    # inside it exceeded the write deadline on 2026-09-23 (D-0195).
    pages = plan.pages
    if target_watch_id is not None:
        pages = (
            tuple(item for item in plan.pages if page_watch_id(item) == target_watch_id)
            or plan.pages
        )
    from swingset.project.history import projection_answer_cached

    year_allowed = _year_gate(conn)
    checkpoint()
    try:
        with projection_answer_cached(), database.transaction():
            if not allocated and (reason := _busy(database, config, clock, deadline)):
                return Dispatch(reason)
            options = [
                (item, _candidate(database, config, clock, item, plan, year_allowed=year_allowed))
                for item in pages
            ]
            for item, (spec, capture, reason) in options:
                page = item.page
                if spec is None or capture is None:
                    blocked = reason
                    if reason == "capture_gap_exhausted" and item.captures:
                        gaps.append(
                            Finding(
                                "history_archive_gap",
                                "event",
                                item.event.event_id,
                                "warning",
                                "Platform capture alternatives are exhausted or incomplete",
                                {
                                    "source": page.source,
                                    "url": page.url,
                                    "year": item.event.year,
                                    "attempts_available": len(item.captures),
                                },
                            )
                        )
                    elif reason == "parent_document_pending":
                        gaps.append(
                            Finding(
                                "history_archive_gap",
                                "event",
                                item.event.event_id,
                                "warning",
                                "Archived sheet waits for its admitted parent declaration",
                                {
                                    "source": page.source,
                                    "url": page.url,
                                    "parent_url": page.parent_url,
                                    "year": item.event.year,
                                },
                            )
                        )
                    continue
                if chosen is not None or (
                    target_watch_id is not None and spec.watch_id != target_watch_id
                ):
                    continue
                # The gate and this mutation share BEGIN IMMEDIATE; changed policies or
                # year acceptance can never leave a newly admitted control behind.
                if schedule_capture(conn, spec, now=clock.now()):
                    conn.execute("UPDATE watches SET priority=6 WHERE watch_id=?", (spec.watch_id,))
                    replace_findings(
                        conn,
                        owner_kind="acquisition_gate",
                        owner_id=spec.watch_id,
                        findings=(),
                        opened_at=clock.now().isoformat(),
                        run_id=run_id,
                    )
                    chosen = item, capture, spec
            replace_findings(
                conn,
                owner_kind="platform_backfill",
                owner_id="retained_plan",
                findings=tuple(gaps),
                opened_at=clock.now().isoformat(),
                run_id=run_id,
            )
    finally:
        resume()
    if chosen is None:
        return Dispatch(blocked)
    _, capture, spec = chosen
    # Direct calls leave two minutes for downstream bookkeeping; fair allocation
    # already reserves offline time. The client retains every actual host gate.
    result = fetcher.fetch(
        spec.watch_id,
        get_page_kind(spec.parser),
        run_id,
        deadline=deadline if allocated else deadline - timedelta(seconds=120),
    )
    if not result.skipped:
        with database.transaction():
            refresh_policy(
                conn, config, spec.watch_id, clock.now(), outcome=result.classification.outcome
            )
    return Dispatch("dispatched", spec.watch_id, capture, result)
