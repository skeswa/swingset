"""Durable, coalescing work and atomic input acceptance."""

from __future__ import annotations

import sqlite3
from collections.abc import Callable, Collection, Iterable, Iterator, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime

from .db import Database


@dataclass(frozen=True, slots=True, order=True)
class WorkUnit:
    stage: str
    unit_kind: str
    unit_id: str


#: The retired whole map (plan F19). Callers that may not change (parse
#: scopes, F12) still queue it when a calendar or index page changes;
#: `enqueue` queues every source's mapping unit in its place.
MAP_ALL = WorkUnit("project", "map", "all")


def enqueue(conn: sqlite3.Connection, units: Iterable[WorkUnit], *, enqueued_at: str) -> None:
    queued = list(units)
    if MAP_ALL in queued:
        from .derivation_dependencies import mapping_units

        queued = [unit for unit in queued if unit != MAP_ALL] + list(mapping_units(conn))
    conn.executemany(
        "INSERT INTO pending_work(stage,unit_kind,unit_id,enqueued_at) VALUES (?,?,?,?) ON CONFLICT(stage,unit_kind,unit_id) DO UPDATE SET enqueued_at=excluded.enqueued_at",
        ((unit.stage, unit.unit_kind, unit.unit_id, enqueued_at) for unit in queued),
    )


def recover_parse_hints(
    database: Database, *, now: datetime, limit: int = 100, wall_seconds: float = 2.0
) -> dict[str, object]:
    """Bounded reconstruction for exact pending snapshots on declared event watches."""
    from .parse_recovery import reconcile

    return reconcile(database, now=now, limit=limit, wall_seconds=wall_seconds)


def accept_inputs(
    database: Database,
    consumer: str,
    inputs: Mapping[str, str],
    affected: Callable[[str, str | None, str, sqlite3.Connection], Iterable[WorkUnit]],
    *,
    accepted_at: str | None = None,
) -> set[str]:
    """Accept changed digests and their complete invalidation set atomically."""
    timestamp = accepted_at or _now()
    changed: set[str] = set()
    with database.transaction() as conn:
        for name, digest in inputs.items():
            row = conn.execute(
                "SELECT digest FROM accepted_inputs WHERE consumer=? AND input_name=?",
                (consumer, name),
            ).fetchone()
            old = None if row is None else str(row[0])
            if old == digest:
                continue
            enqueue(conn, affected(name, old, digest, conn), enqueued_at=timestamp)
            conn.execute(
                "INSERT INTO accepted_inputs(consumer,input_name,digest) VALUES (?,?,?) ON CONFLICT(consumer,input_name) DO UPDATE SET digest=excluded.digest",
                (consumer, name, digest),
            )
            changed.add(name)
    return changed


def accept_input(
    database: Database,
    consumer: str,
    input_name: str,
    digest: str,
    units: Iterable[WorkUnit],
    *,
    accepted_at: str | None = None,
) -> bool:
    materialized = tuple(units)
    changed = accept_inputs(
        database,
        consumer,
        {input_name: digest},
        lambda _name, _old, _new, _conn: materialized,
        accepted_at=accepted_at,
    )
    return input_name in changed


def next_work(
    conn: sqlite3.Connection,
    stage: str,
    *,
    now: datetime | None = None,
    fingerprint: Callable[[WorkUnit], str] | None = None,
    exclude: Collection[WorkUnit] = (),
    allowed: Callable[[WorkUnit], bool] | None = None,
    unit_kind: str | None = None,
) -> WorkUnit | None:
    return next(
        iter_work(
            conn,
            stage,
            now=now,
            fingerprint=fingerprint,
            exclude=exclude,
            allowed=allowed,
            unit_kind=unit_kind,
        ),
        None,
    )


def iter_work(
    conn: sqlite3.Connection,
    stage: str,
    *,
    now: datetime | None = None,
    fingerprint: Callable[[WorkUnit], str] | None = None,
    exclude: Collection[WorkUnit] = (),
    allowed: Callable[[WorkUnit], bool] | None = None,
    unit_kind: str | None = None,
    current_hints: dict[WorkUnit, str] | None = None,
) -> Iterator[WorkUnit]:
    """Eligible units in selection order, walking the candidates once (D-0182).

    ``current_hints`` collects project and link hints found current
    (`derivations.candidate_units`).
    """
    order = (
        "CASE unit_kind WHEN 'mapping' THEN 0 WHEN 'resolution' THEN 1 WHEN 'year' THEN 3 WHEN 'history' THEN 3 "
        "ELSE 2 END,enqueued_at,unit_kind,unit_id"
        if stage == "project"
        else "enqueued_at,unit_kind,unit_id"
    )
    attempts_available = (
        conn.execute("SELECT 1 FROM sqlite_master WHERE name='work_attempts'").fetchone()
        is not None
    )
    from . import derivations

    derived = stage in {"project", "link"} and derivations.available(conn)
    units = (
        derivations.candidate_units(conn, stage, kind=unit_kind, current_hints=current_hints)
        if derived
        else (
            WorkUnit(str(row[0]), str(row[1]), str(row[2]))
            for row in conn.execute(
                f"SELECT stage,unit_kind,unit_id FROM pending_work WHERE stage=? ORDER BY {order}",
                (stage,),
            )
        )
    )
    for unit in units:
        if (
            (unit_kind is not None and unit.unit_kind != unit_kind)
            or unit in exclude
            or (allowed is not None and not allowed(unit))
        ):
            continue
        if derived and not derivations.ready(conn, unit):
            continue
        if not attempts_available:
            yield unit
            continue
        from .attempts import eligible, latest_attempt
        from .queue import holds
        from .work_fingerprints import input_fingerprint

        moment = now or datetime.now(UTC)

        def current(unit: WorkUnit = unit) -> str:
            return fingerprint(unit) if fingerprint else input_fingerprint(conn, unit)

        latest = latest_attempt(conn, unit)
        if (latest is None or latest["outcome"] in {"succeeded", "superseded"}) and holds(
            conn, unit, moment, current
        ):
            # No attempt carries this failure's clock: the queue row does.
            continue
        if latest is None or eligible(conn, unit, current(), moment):
            yield unit


def unfinished_units(
    conn: sqlite3.Connection,
    stages: Iterable[str] = ("parse", "project", "link"),
) -> Iterable[WorkUnit]:
    """All unfinished work, regardless of retry or control eligibility."""
    from . import derivations

    for stage in stages:
        if stage in {"project", "link"} and derivations.available(conn):
            yield from derivations.pending_units(conn, stage)
        else:
            yield from (
                WorkUnit(*row)
                for row in conn.execute(
                    "SELECT stage,unit_kind,unit_id FROM pending_work WHERE stage=? ORDER BY unit_kind,unit_id",
                    (stage,),
                )
            )


def runnable_exists(
    conn: sqlite3.Connection,
    *,
    now: datetime | None = None,
    fingerprint: Callable[[WorkUnit], str] | None = None,
    exclude: Collection[WorkUnit] = (),
    allowed: Callable[[WorkUnit], bool] | None = None,
) -> bool:
    """Blocked pending work remains unfinished, but does not prohibit healthy I/O."""
    return any(
        next_work(conn, stage, now=now, fingerprint=fingerprint, exclude=exclude, allowed=allowed)
        is not None
        for stage in ("parse", "project", "link")
    )


def complete(
    database: Database, unit: WorkUnit, write: Callable[[sqlite3.Connection], None]
) -> None:
    """Commit a unit's output, downstream work, and completion together."""
    with database.transaction() as conn:
        exists = conn.execute(
            "SELECT 1 FROM pending_work WHERE stage=? AND unit_kind=? AND unit_id=?",
            (unit.stage, unit.unit_kind, unit.unit_id),
        ).fetchone()
        from . import derivations

        if exists is None and not (
            unit.stage in {"project", "link"} and derivations.available(conn)
        ):
            return
        write(conn)
        conn.execute(
            "DELETE FROM pending_work WHERE stage=? AND unit_kind=? AND unit_id=?",
            (unit.stage, unit.unit_kind, unit.unit_id),
        )


def bump_revision(conn: sqlite3.Connection, name: str) -> None:
    cursor = conn.execute("UPDATE revisions SET value=value+1 WHERE name=?", (name,))
    if cursor.rowcount != 1:
        raise ValueError(f"unknown revision: {name}")


def affected_work(conn: sqlite3.Connection, input_name: str) -> Iterable[WorkUnit]:
    """The centralized invalidation map from the state contract.

    Code scopes (D-0207): an extract or parse scope invalidates like its kind's
    version label. A project or link scope queues that kind's units, and
    the legacy package-wide `recipe/runtime` queues every
    parse, project and link unit. Derivations see these inputs in their
    fingerprints anyway; the queue rows are hints, so the watchdog, which
    reads only `pending_work`, sees the backlog (I4). The build is paced and
    needs none.
    """
    if input_name.startswith("recipe/code/extract/"):
        input_name = "version/extract/" + input_name.removeprefix("recipe/code/extract/")
    elif input_name.startswith("recipe/code/parse/"):
        input_name = "version/parser/" + input_name.removeprefix("recipe/code/parse/")
    elif input_name.startswith("recipe/code/"):
        return derivation_hints(conn, input_name.removeprefix("recipe/code/"))
    if input_name == "recipe/env":
        return ()
    if input_name == "recipe/runtime":
        manual_crosscheck = (
            "source='crosscheck' AND kind='registry_dump' AND method='MANUAL' "
            "AND parser='registry_crosscheck'"
        )
        conn.execute(f"UPDATE watches SET extract_version=NULL WHERE NOT ({manual_crosscheck})")
        return (
            *(
                WorkUnit("parse", "snapshot", str(row[0]))
                for row in conn.execute(
                    "SELECT s.snapshot_id FROM snapshots s JOIN watches w USING(watch_id) "
                    "WHERE NOT (w.source='crosscheck' AND w.kind='registry_dump' "
                    "AND w.method='MANUAL' AND w.parser='registry_crosscheck')"
                )
            ),
            *derivation_hints(conn, None),
        )
    if input_name.startswith(("extract_version:", "version/extract/")):
        kind = input_name.rsplit(":" if ":" in input_name else "/", 1)[1]
        conn.execute(
            "UPDATE watches SET extract_version=NULL WHERE parser=? OR kind=?", (kind, kind)
        )
        rows = conn.execute(
            "SELECT snapshot_id FROM snapshots WHERE watch_id IN (SELECT watch_id FROM watches WHERE parser=? OR kind=?)",
            (kind, kind),
        )
        return tuple(WorkUnit("parse", "snapshot", str(row[0])) for row in rows)
    if input_name.startswith(("parser_version:", "version/parser/")):
        kind = input_name.rsplit(":" if ":" in input_name else "/", 1)[1]
        rows = conn.execute(
            "SELECT snapshot_id FROM snapshots WHERE watch_id IN (SELECT watch_id FROM watches WHERE parser=? OR kind=?)",
            (kind, kind),
        )
        return tuple(WorkUnit("parse", "snapshot", str(row[0])) for row in rows)
    if input_name in {
        "projector_version",
        "projection_vocabulary",
        "event_vocabulary",
        "version/projector",
    }:
        units = {
            WorkUnit("project", str(row[0]), str(row[1]))
            for row in conn.execute("SELECT DISTINCT scope_kind,scope_id FROM observations")
        }
        units.update(
            WorkUnit("project", str(row[0]), str(row[1]))
            for row in conn.execute(
                "SELECT DISTINCT scope_kind,scope_id FROM canonical_scope_rows WHERE scope_kind IN ('calendar','event','dancer')"
            )
        )
        units.update(
            WorkUnit("project", "source_index", str(row[0]))
            for row in conn.execute("SELECT DISTINCT scope_id FROM source_event_scope_rows")
        )
        from .derivation_dependencies import mapping_units

        units.update(mapping_units(conn))
        return tuple(sorted(units))
    if input_name in {"overrides/series_aliases.csv", "overrides/finding_reviews.csv"}:
        # The inventory reads both files; the years read what it writes, and
        # a year the edit does not change cuts off (plan F17).
        if conn.execute(
            "SELECT 1 FROM events UNION SELECT 1 FROM registry_placements UNION SELECT 1 FROM observations WHERE scope_kind='calendar' LIMIT 1"
        ).fetchone():
            from . import derivations

            if not derivations.available(conn):
                return (WorkUnit("project", "history", "all"),)
            from .derivation_dependencies import year_units

            return (WorkUnit("project", "inventory", "all"), *year_units(conn))
        return ()
    if input_name in {
        "event_aliases",
        "source_urls",
        "overrides/event_aliases.csv",
        "overrides/source_urls.csv",
    }:
        # Every known source's mapping; `state/inputs.accept` adds the
        # sources only the new file names (plan F19).
        from .derivation_dependencies import mapping_units

        return mapping_units(conn)
    if input_name in {
        "weights",
        "nicknames",
        "identity_overrides",
        "linker_version",
        "link/weights.toml",
        "overrides/nicknames.csv",
        "overrides/identity_overrides.csv",
        "version/linker",
    }:
        rows = conn.execute(
            "SELECT event_id FROM events UNION SELECT substr(subject_id,1,instr(subject_id,'/')-1) FROM identity_links WHERE instr(subject_id,'/')>0"
        )
        return tuple(WorkUnit("link", "event", str(row[0])) for row in rows)
    return ()


def derivation_hints(conn: sqlite3.Connection, scope: str | None) -> tuple[WorkUnit, ...]:
    """Queue hints for the derivation units a code scope names.

    `project/<kind>` names that kind's units, `link` every link unit, and
    None (the environment) every project and link unit; `build` names none.
    """
    from .derivations import known_units

    if scope is None:
        return (*known_units(conn, "project"), *known_units(conn, "link"))
    if scope == "link":
        return tuple(known_units(conn, "link"))
    if scope.startswith("project/"):
        kind = scope.removeprefix("project/")
        return tuple(unit for unit in known_units(conn, "project") if unit.unit_kind == kind)
    return ()


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")
