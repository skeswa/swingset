"""Eligible demand shares request debits; offline work rotates independently.

Selections are read-only hints. The HTTP gate repeats the pressure check and
records service in the same transaction as its existing durable host debit.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Callable, Collection, Iterable, Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlsplit

from swingset.config import Config
from swingset.history.acquisition import is_phase_one_index
from swingset.state.control_scopes import for_watch
from swingset.state.controls import ActionScope, matching_pauses
from swingset.state.work import WorkUnit

from .event_capacity import Selection as CapacitySelection
from .event_turns import Selection
from .fair_policy import shares


@dataclass(frozen=True)
class WatchChoice:
    key: str
    watch_id: str | None
    host: str
    category: str
    scope: ActionScope
    due_at: datetime
    repair: bool = False
    archive: bool = False
    history: bool = False
    turn: Selection | None = None
    capacity: CapacitySelection | None = None


@dataclass(frozen=True)
class _Service:
    choice: WatchChoice
    run_id: str


_service: ContextVar[_Service | None] = ContextVar("scheduler_service", default=None)


#: Hosts whose due watches the selection left out for a failed robots read,
#: each with its retry; set by the acquisition pass (`noting_robots`).
_robots_dropped: ContextVar[dict[str, datetime] | None] = ContextVar("robots_dropped", default=None)


@contextmanager
def noting_robots(dropped: dict[str, datetime]) -> Iterator[None]:
    """Collect into ``dropped`` the hosts left out for a failed robots read.

    Only a host that had a due watch is noted, so the pass's guard says a
    fetch was held, not merely that a host's robots read failed (D-0242).
    """
    token = _robots_dropped.set(dropped)
    try:
        yield
    finally:
        _robots_dropped.reset(token)


@contextmanager
def servicing(choice: WatchChoice, *, run_id: str) -> Iterator[None]:
    token = _service.set(_Service(choice, run_id))
    try:
        yield
    finally:
        _service.reset(token)


# Parse rows derive could run now: no queue row, a lease, or ready and due.
# A row waiting on a clock (a backoff, waiting for input, quarantined) does
# not hold acquisition (D-0216, F9).
_RUNNABLE_PARSE = (
    "FROM pending_work p LEFT JOIN work_queue q "
    "ON q.stage=p.stage AND q.unit_kind=p.unit_kind AND q.unit_id=p.unit_id "
    "WHERE p.stage='parse' AND (q.state IS NULL OR q.state='leased' OR "
    "(q.state='ready' AND (q.next_attempt_at IS NULL OR q.next_attempt_at<=:now)))"
)


def backpressure(
    conn: sqlite3.Connection, config: Config, *, now: datetime | None = None
) -> dict[str, Any]:
    """Whether pending parse work should hold acquisition.

    Only parse units derive could run now count, by items and by bytes;
    before schema 34 every pending parse row does.
    """
    counts = dict(conn.execute("SELECT stage,count(*) FROM pending_work GROUP BY stage"))
    queued = (
        conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='work_queue'"
        ).fetchone()
        is not None
    )
    if queued:
        from swingset.state.queue import at

        moment = {"now": at(now or datetime.now(UTC))}
        runnable = int(conn.execute("SELECT count(*) " + _RUNNABLE_PARSE, moment).fetchone()[0])
        size = conn.execute(
            "SELECT coalesce(sum(size),0) FROM (SELECT s.body_sha256,max(s.body_bytes) AS size "
            "FROM snapshots s JOIN (SELECT p.unit_id " + _RUNNABLE_PARSE + ") r "
            "ON r.unit_id=s.snapshot_id GROUP BY s.body_sha256)",
            moment,
        ).fetchone()[0]
    else:
        runnable = int(counts.get("parse", 0))
        size = conn.execute(
            "SELECT coalesce(sum(size),0) FROM (SELECT s.body_sha256,max(s.body_bytes) AS size "
            "FROM pending_work p JOIN snapshots s ON p.unit_id=s.snapshot_id "
            "WHERE p.stage='parse' GROUP BY s.body_sha256)"
        ).fetchone()[0]
    reasons = []
    if size >= config.scheduler.pending_parse_bytes:
        reasons.append("pending_parse_bytes")
    if runnable >= config.scheduler.pending_parse_items:
        reasons.append("pending_parse_items")
    # With derivations, project and link rows are hints: derive re-checks
    # fingerprints, and a code-scope accept or a replay epoch queues every
    # unit it makes stale (state/work.derivation_hints). A derivation backlog
    # does not pause acquisition (I5, D-0214); parse work still does.
    from swingset.state.derivations import available

    total = (
        runnable
        if available(conn)
        else runnable + sum(count for stage, count in counts.items() if stage != "parse")
    )
    if total >= config.scheduler.pending_work_items:
        reasons.append("pending_work_items")
    return {
        "active": bool(reasons),
        "reasons": reasons,
        "pending": counts,
        "runnable_parse": runnable,
        "pending_parse_bytes": size,
        "repair_requests_per_cycle": config.scheduler.repair_requests_per_cycle,
    }


def report(conn: sqlite3.Connection, config: Config, *, now: datetime) -> dict[str, Any]:
    """Separate initial objectives from observed debits; never migrate a doctor read."""
    supported = (
        conn.execute("SELECT 1 FROM sqlite_master WHERE name='scheduler_requests'").fetchone()
        is not None
    )
    service = []
    if supported:
        service = [
            {
                "host": host,
                "category": category,
                "requests_today": requests,
                "body_bytes_today": size,
                "last_issued_at": last,
                "last_issued_wall_age_seconds": max(
                    0.0, (now - datetime.fromisoformat(last)).total_seconds()
                ),
            }
            for host, category, requests, size, last in conn.execute(
                "SELECT host,category,sum(day=?),sum(CASE WHEN day=? THEN body_bytes ELSE 0 END),max(issued_at) "
                "FROM scheduler_requests GROUP BY host,category",
                (now.date().isoformat(), now.date().isoformat()),
            )
        ]
    return {
        "supported": supported,
        "initial_objectives": {
            **asdict(config.scheduler),
            "host_class_percentages": {host: shares(host) for host in sorted(config.hosts)},
        },
        "observed_host_usage": [
            dict(row)
            for row in conn.execute(
                "SELECT host,day,requests,bytes FROM host_budget WHERE day=? ORDER BY host",
                (now.date().isoformat(),),
            )
        ],
        "observed_attributed_service": service if supported else None,
        "observed_offline_attempts": [
            dict(row)
            for row in conn.execute(
                "SELECT stage,unit_kind,attempts,last_served_at FROM scheduler_offline_service ORDER BY stage,unit_kind"
            )
        ]
        if supported
        else None,
        "recent_repair_reservation_runs": [
            dict(row)
            for row in conn.execute(
                "SELECT run_id,count(*) AS issued_requests,max(issued_at) AS last_issued_at FROM scheduler_requests "
                "WHERE pressure_reserved=1 GROUP BY run_id ORDER BY last_issued_at DESC LIMIT 20"
            )
        ]
        if supported
        else None,
        "attribution_note": "Issued HTTP only; pre-policy debits remain charged but unattributed. Wall ages include pauses and do not establish eligible service-gap performance.",
        "backpressure": backpressure(conn, config, now=now),
    }


def request_denial(
    conn: sqlite3.Connection,
    config: Config,
    *,
    watch_id: str | None = None,
    host: str | None = None,
    now: datetime | None = None,
    independent: bool = False,
) -> str | None:
    """Called before the durable host debit, including for robots and redirects."""
    service = None if independent else _service.get()
    if backpressure(conn, config, now=now)["active"] and (
        service is None
        or not service.choice.repair
        or not _repair_capacity(conn, config, service.run_id)
    ):
        return "pending work backpressure"
    if now is not None:
        from .event_pressure import request_denial as expansion_denial

        return expansion_denial(
            conn,
            config,
            watch_id=watch_id or (service.choice.watch_id if service else None),
            host=host or (service.choice.host if service else None),
            now=now,
        )
    return None


def request_permitted(conn: sqlite3.Connection, config: Config, **kwargs: Any) -> bool:
    return request_denial(conn, config, **kwargs) is None


def _repair_capacity(conn: sqlite3.Connection, config: Config, run_id: str) -> bool:
    used = conn.execute(
        "SELECT count(*) FROM scheduler_requests WHERE run_id=? AND pressure_reserved=1",
        (run_id,),
    ).fetchone()[0]
    return bool(used < config.scheduler.repair_requests_per_cycle)


def record_request(
    conn: sqlite3.Connection,
    config: Config,
    *,
    action_id: str,
    host: str,
    watch_id: str | None,
    source: str,
    now: datetime,
) -> None:
    if not conn.in_transaction:
        raise RuntimeError("scheduler request accounting requires the host debit transaction")
    service = _service.get()
    conn.execute(
        "INSERT INTO scheduler_requests(action_id,host,day,category,work_key,run_id,repair,pressure_reserved,issued_at) "
        "VALUES (?,?,?,?,?,?,?,?,?)",
        (
            action_id,
            host,
            now.date().isoformat(),
            service.choice.category
            if service
            else ("identity" if source == "wsdc_registry" else "current"),
            service.choice.key if service else watch_id or source,
            service.run_id if service else None,
            bool(service and service.choice.repair),
            bool(
                service and service.choice.repair and backpressure(conn, config, now=now)["active"]
            ),
            now.isoformat(),
        ),
    )
    if service:
        from .event_capacity import record as record_capacity
        from .event_turns import record

        record(conn, service.choice, action_id=action_id, now=now)
        record_capacity(conn, service.choice, action_id=action_id)
    from .event_pressure import record_started

    record_started(conn, config, watch_id=watch_id, host=host, now=now)


def _choices(conn: sqlite3.Connection, config: Config, now: datetime) -> Iterator[WatchChoice]:
    # Archive captures require the dispatcher's year/parent/capture offer. They
    # must not bypass that gate merely because a watch already exists.
    from swingset.history.origin_dispatch import available

    managed_origin = (
        {row[0] for row in conn.execute("SELECT watch_id FROM history_origin_intents")}
        if available(conn)
        else set()
    )
    rows = conn.execute(
        "SELECT w.*, EXISTS(SELECT 1 FROM snapshots s WHERE s.watch_id=w.watch_id) AS retained "
        "FROM watches w WHERE state NOT IN ('sealed','retired') AND next_check_at IS NOT NULL "
        "ORDER BY priority,next_check_at,watch_id",
    )
    for row in rows:
        if row["watch_id"] in managed_origin:
            continue
        if not config.enabled(row["source"]):
            continue
        if datetime.fromisoformat(row["next_check_at"]) > now:
            continue
        if row["archive_url"] and not is_phase_one_index(row["source"], row["parser"], row["kind"]):
            continue
        if row["paused_until"] and datetime.fromisoformat(row["paused_until"]) > now:
            continue
        host = urlsplit(row["archive_url"] or row["url"]).hostname
        if not host:
            continue
        if row["source"] == "wsdc_registry":
            category = (
                "old"
                if row["notes"] == "sweep"
                else "new"
                if row["notes"] == "probe"
                else "identity"
            )
        elif not row["retained"] and row["last_checked_at"] is None:
            category = "new"
        elif row["state"] in {"live", "upcoming", "cooling"}:
            category = "current"
        else:
            category = "old"
        # Ordinary newly discovered rounds are not repair capacity. Only a
        # retained, explicitly ready identity dependency receives this reserve.
        repair = (
            row["source"] == "wsdc_registry"
            and conn.execute(
                "SELECT 1 FROM findings WHERE closed_at IS NULL AND kind='source_id_checked' "
                "AND state='ready' AND (watch_id=? OR subject_id=?) LIMIT 1",
                (row["watch_id"], str(row["source_ref"] or "").removeprefix("wsdc:")),
            ).fetchone()
            is not None
        )
        yield WatchChoice(
            str(row["watch_id"]),
            str(row["watch_id"]),
            host,
            category,
            for_watch(conn, source=row["source"], watch_id=row["watch_id"], host=host),
            datetime.fromisoformat(row["next_check_at"]),
            repair=repair,
        )


def _delay(
    conn: sqlite3.Connection, config: Config, choice: WatchChoice, now: datetime, pressure: bool
) -> float | None:
    if choice.category not in shares(choice.host):
        raise ValueError(f"unknown scheduling category: {choice.category}")
    if any(not config.enabled(source) for source in choice.scope.sources):
        return None
    if matching_pauses(conn, choice.scope, now=now) or (pressure and not choice.repair):
        return None
    budget = conn.execute(
        "SELECT requests,bytes FROM host_budget WHERE host=? AND day=?",
        (choice.host, now.date().isoformat()),
    ).fetchone()
    policy = config.host(choice.host)
    # Fair scheduling never activates the separately authorized bootstrap sweep.
    if budget and (
        budget[0] >= policy.daily_request_budget
        or (policy.daily_byte_budget is not None and budget[1] >= policy.daily_byte_budget)
    ):
        return None
    delay = max(0.0, (choice.due_at - now).total_seconds())
    host = conn.execute(
        "SELECT next_allowed_at,paused_until FROM hosts WHERE host=?", (choice.host,)
    ).fetchone()
    if host:
        if host[1] and datetime.fromisoformat(host[1]) > now:
            return None
        if host[0]:
            delay = max(delay, (datetime.fromisoformat(host[0]) - now).total_seconds())
    return delay


def _eligible(
    conn: sqlite3.Connection,
    config: Config,
    now: datetime,
    exclude: Collection[str],
    extra_choices: Iterable[WatchChoice],
    run_id: str | None,
) -> Iterator[tuple[WatchChoice, float]]:
    from swingset.fetch.robots import blocked

    from .event_pressure import request_denial as expansion_denial

    host_decisions: dict[str, dict[str, Any]] = {}
    pressure = bool(backpressure(conn, config, now=now)["active"])
    if pressure and run_id is not None and not _repair_capacity(conn, config, run_id):
        return
    # A host whose robots read failed disallows every request until its
    # retry, so none of its watches is a candidate: each would only skip, and
    # each skip re-ran this selection over every due watch (D-0242).
    unreadable = blocked(conn, now)
    seen = set(exclude)
    for choice in (*extra_choices, *_choices(conn, config, now)):
        if choice.key in seen:
            continue
        seen.add(choice.key)
        if choice.host in unreadable:
            if (dropped := _robots_dropped.get()) is not None:
                dropped[choice.host] = unreadable[choice.host]
            continue
        if expansion_denial(
            conn,
            config,
            watch_id=choice.watch_id,
            host=choice.host,
            now=now,
            host_decisions=host_decisions,
        ):
            continue
        delay = _delay(conn, config, choice, now, pressure)
        if delay is not None:
            yield choice, delay


def prepare_event_turns(
    conn: sqlite3.Connection,
    config: Config,
    *,
    now: datetime,
    exclude: Collection[str] = (),
    extra_choices: Iterable[WatchChoice] = (),
    run_id: str | None = None,
) -> None:
    from .event_pressure import sync
    from .event_turns import prepare

    sync(conn, config, now=now)

    choices = [
        choice
        for choice, delay in _eligible(conn, config, now, exclude, extra_choices, run_id)
        if delay <= 0
    ]
    prepare(conn, config, choices, now=now)


def next_watch(
    conn: sqlite3.Connection,
    config: Config,
    *,
    now: datetime,
    exclude: Collection[str] = (),
    extra_choices: Iterable[WatchChoice] = (),
    run_id: str | None = None,
) -> WatchChoice | None:
    candidates = [
        choice
        for choice, delay in _eligible(conn, config, now, exclude, extra_choices, run_id)
        if delay <= 0
    ]
    if not candidates:
        return None
    counts = {
        (str(host), str(category)): int(count)
        for host, category, count in conn.execute(
            "SELECT host,category,count(*) FROM scheduler_requests WHERE day=? GROUP BY host,category",
            (now.date().isoformat(),),
        )
    }
    services = {
        (str(host), str(category)): datetime.fromisoformat(at)
        for host, category, at in conn.execute(
            "SELECT host,category,max(issued_at) FROM scheduler_requests GROUP BY host,category"
        )
    }
    host_latest = {
        host: max(at for (h, _), at in services.items() if h == host) for host, _ in services
    }

    def rank(choice: WatchChoice) -> tuple[float, float, float, datetime, str]:
        last = services.get((choice.host, choice.category), choice.due_at)
        age = max(0.0, (now - last).total_seconds())
        overdue = age >= config.scheduler.service_gap_seconds
        weighted = counts.get((choice.host, choice.category), 0) / max(
            1, shares(choice.host)[choice.category]
        )
        host_age = (now - host_latest.get(choice.host, choice.due_at)).total_seconds()
        return (-age if overdue else 0, -host_age, weighted, choice.due_at, choice.key)

    winner = min(candidates, key=rank)
    from .event_capacity import choose

    group = sorted(
        (
            choice
            for choice in candidates
            if (choice.host, choice.category) == (winner.host, winner.category)
        ),
        key=rank,
    )
    return choose(conn, config, group)


def next_delay(
    conn: sqlite3.Connection,
    config: Config,
    *,
    now: datetime,
    exclude: Collection[str] = (),
    extra_choices: Iterable[WatchChoice] = (),
    run_id: str | None = None,
) -> float | None:
    return min(
        (delay for _, delay in _eligible(conn, config, now, exclude, extra_choices, run_id)),
        default=None,
    )


def next_offline(
    conn: sqlite3.Connection,
    *,
    now: datetime,
    allowed: Callable[[WorkUnit], bool] | None = None,
    exclude: Collection[WorkUnit] = (),
) -> WorkUnit | None:
    units = next_offline_batch(conn, now=now, allowed=allowed, exclude=exclude, limit=1)
    return units[0] if units else None


def next_offline_batch(
    conn: sqlite3.Connection,
    *,
    now: datetime,
    allowed: Callable[[WorkUnit], bool] | None = None,
    exclude: Collection[WorkUnit] = (),
    limit: int = 64,
    errors: dict[str, str] | None = None,
    current_hints: dict[WorkUnit, str] | None = None,
) -> list[WorkUnit]:
    """Up to ``limit`` eligible units from one read snapshot, in selection order.

    A kind whose recipe cannot be formed (`RecipeScopeMissing`) is skipped and
    named in ``errors`` by `stage/kind`; the other kinds stay runnable (I1).
    Project and link hints the walk found current land in ``current_hints``,
    for the caller to delete after the snapshot (`derivations.drop_current_hints`).

    Selecting one unit costs seconds on a large database because currentness
    is recomputed for thousands of candidates, and the memo that makes repeat
    answers cheap lives only inside one snapshot. Taking a batch per snapshot
    amortizes that cost; every unit is re-validated when it is derived, so a
    stale pick is superseded, never wrong (D-0182).
    """
    from swingset.state.derivation_query import read_snapshot

    # All stage/kind candidates share one owned read snapshot and bounded
    # currentness answers. Caller-owned mutable transactions remain uncached.
    with read_snapshot(conn):
        return _next_offline_batch(
            conn,
            now=now,
            allowed=allowed,
            exclude=exclude,
            limit=max(1, limit),
            errors=errors,
            current_hints=current_hints,
        )


def _next_offline(
    conn: sqlite3.Connection,
    *,
    now: datetime,
    allowed: Callable[[WorkUnit], bool] | None = None,
    exclude: Collection[WorkUnit] = (),
) -> WorkUnit | None:
    units = _next_offline_batch(conn, now=now, allowed=allowed, exclude=exclude)
    return units[0] if units else None


def _next_offline_batch(
    conn: sqlite3.Connection,
    *,
    now: datetime,
    allowed: Callable[[WorkUnit], bool] | None = None,
    exclude: Collection[WorkUnit] = (),
    limit: int = 1,
    errors: dict[str, str] | None = None,
    current_hints: dict[WorkUnit, str] | None = None,
) -> list[WorkUnit]:
    from swingset.state.derivations import available, known_units
    from swingset.state.recipes import RecipeScopeMissing
    from swingset.state.work import iter_work

    selected: list[WorkUnit] = []
    derived = available(conn)
    if derived:
        kinds = {
            (str(row[0]), str(row[1]))
            for row in conn.execute(
                "SELECT DISTINCT stage,unit_kind FROM pending_work WHERE stage='parse'"
            )
        }
        kinds.update(
            (unit.stage, unit.unit_kind)
            for stage in ("project", "link")
            for unit in known_units(conn, stage)
        )
        service = {
            (row[0], row[1]): row[2]
            for row in conn.execute(
                "SELECT stage,unit_kind,sequence FROM scheduler_offline_service"
            )
        }
        stage_order = {"parse": 0, "project": 1, "link": 2}
        kind_order = {
            "calendar": 0,
            "source_index": 0,
            "dancer": 0,
            "inventory": 1,
            "mapping": 2,
            "resolution": 3,
            "event": 4,
            "source_event": 5,
            "year": 6,
        }
        groups = [
            (stage, kind, service.get((stage, kind), 0))
            for stage, kind in sorted(
                kinds,
                key=lambda key: (
                    service.get(key, 0),
                    stage_order[key[0]],
                    kind_order.get(key[1], 0),
                    key[1],
                ),
            )
        ]
    else:
        groups = conn.execute(
            "SELECT DISTINCT p.stage,p.unit_kind,coalesce(s.sequence,0) AS seq FROM pending_work p "
            "LEFT JOIN scheduler_offline_service s ON p.stage=s.stage AND p.unit_kind=s.unit_kind "
            "WHERE p.stage IN ('parse','project','link') ORDER BY seq,"
            "CASE p.stage WHEN 'parse' THEN 0 WHEN 'project' THEN 1 ELSE 2 END,"
            "CASE p.unit_kind WHEN 'mapping' THEN 0 WHEN 'resolution' THEN 1 "
            "WHEN 'year' THEN 3 WHEN 'history' THEN 3 ELSE 2 END,p.unit_kind"
        ).fetchall()
    for stage, kind, _ in groups:

        def group_allowed(unit: WorkUnit, kind: str = kind) -> bool:
            return bool(unit.unit_kind == kind and (allowed is None or allowed(unit)))

        try:
            # A link waits for the dancers its read set names, checked per
            # link by `ready`, not for the whole registry (plan F20).
            for unit in iter_work(
                conn,
                stage,
                now=now,
                exclude=exclude,
                allowed=group_allowed,
                unit_kind=kind,
                current_hints=current_hints,
            ):
                selected.append(unit)
                if len(selected) >= limit:
                    return selected
        except RecipeScopeMissing as exc:
            # A defect in one kind's code scope must not stall every kind.
            if errors is not None:
                errors[f"{stage}/{kind}"] = str(exc)[:200]
        if selected:
            # One group per batch keeps the recorded service order honest.
            return selected
    return selected


def record_offline_service(conn: sqlite3.Connection, unit: WorkUnit, *, now: datetime) -> None:
    conn.execute(
        "INSERT INTO scheduler_offline_service(stage,unit_kind,attempts,last_served_at,sequence) "
        "VALUES (?,?,1,?,(SELECT coalesce(max(sequence),0)+1 FROM scheduler_offline_service)) "
        "ON CONFLICT(stage,unit_kind) DO UPDATE SET attempts=attempts+1,last_served_at=excluded.last_served_at,sequence=excluded.sequence",
        (unit.stage, unit.unit_kind, now.isoformat()),
    )
